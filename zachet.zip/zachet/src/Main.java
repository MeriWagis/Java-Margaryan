import java.util.Calendar;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Baza list = new Baza();
        System.out.println("Программа запущена");
        Scanner scanner = new Scanner(System.in);
        list.addTask("Сумерки", "21:50", "12", "A11");
        list.addTask("Фиксики", "13:00", "3", "A32");
        list.addTask("Каддилак Долана", "23:50", "4","B5");
        list.addTask("Три богатыря и ход конем", "15:50", "12","C3");
        list.printAllTasks();
        {
            while (true) {
                System.out.println("Введите команду: ");
                String command = scanner.nextLine();
                if (command.equalsIgnoreCase("1")) {
                    create(scanner, list);
                    System.out.println("Создан!");
                    // 1 Создать
//                } else if (command.equalsIgnoreCase("2")) {
//                    delete(scanner, list);
//                    System.out.println("Удален");
//                    // 2 Удалить
//                } else if (command.equalsIgnoreCase("3")) {
//                    edit(scanner, list);
//                    System.out.println("Отредактировано");
//                    // 3 Отредактировать
//                } else if (command.equalsIgnoreCase("4")) {
//                    complete(scanner, list);
//                    System.out.println("Изменен статус");
//                    // 4 Отметить как выполненно
//                    // 5 Получить детальную информацию
                } else if (command.equalsIgnoreCase("6.1")) {
                    System.out.println("База заданий");
                    list.printAllTasks();
                    // 6.1 Все
                } else if (command.equalsIgnoreCase("6.2")) {
                    System.out.println("Выполненные");
                    list.printDoneTasks();
                    // 6.2 Выполненные
                } else if (command.equalsIgnoreCase("6.3")) {
                    System.out.println("Невыполненные");
                    list.printUndoneTasks();

                }
            }

        }

    }
    public static boolean checkName(String name) {
        if (!name.equals("")) {
            return !Character.isDigit(name.charAt(0));
        }
        return true;
    }
    public static void create(Scanner scanner, Baza list) {
        String name;
        while (true) {
            System.out.println("Введите имя задания (не начинается с цифры))");
            name = scanner.nextLine().trim();
            if (name.equalsIgnoreCase("0")) {
                return;
            } else if (!checkName(name)) {
                System.out.println("Некорректное имя, попробуйте снова");
                System.out.println("Для отмены введите 0");
            } else { // имя подходит
                break;
            }
        }
        System.out.println("Описание задания:");
        String Opis = scanner.nextLine().trim();
        System.out.println("Введите id user:");
        String num_user  = scanner.nextLine().trim();
        System.out.println("Введите место:");
        String mesto  = scanner.nextLine().trim();
        list.addTask("Три богатыря и ход конем", "15:50", "12", "C1");

    }
}