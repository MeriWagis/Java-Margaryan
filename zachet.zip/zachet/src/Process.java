import java.util.Calendar;

public class Process {
    int num; // id фильма
    String num_user = ""; // id смотрящего фильм
    String name; // Наименование фильма
    String Opis = ""; // записывает время сеанса
    String mesto = "";
    boolean Sost; // Занят ли билет?

    Process(String name){
        this.name = name;
        this.Opis = "";
        this.mesto = "";
        this.Sost = false;
        this.num = 0;
        this.num_user="";

    }
    Process(String name, String Opis, String num_user, String mesto){
        this.name = name;
        this.Opis = Opis;
        this.Sost = false;
        this.num = 0;
        this.num_user=num_user;
        this.mesto = mesto;
    }
}
