import java.util.ArrayList;
//List<String> messages = Arrays.asList("Hello", "World!", "How", "Are", "You");
import java.util.ArrayList;
import java.util.Calendar;
public class Baza {
    ArrayList<Process> list;
    int idCounter;
    Baza() {
        this.list= new ArrayList<Process>();
        this.idCounter = 1;
    }

    public void addTask(Process newTask) {
        this.list.add(newTask);
        newTask.num = this.idCounter;
        this.idCounter++;
    }

    public void addTask(String name, Calendar dueDate) {
        Process newTask = new Process(name, dueDate);
        this.list.add(newTask);
        newTask.num = this.idCounter;
        this.idCounter++;
    }

    public void addTask(String name, Calendar dueDate, String description) {
        Process newTask = new Process(name, dueDate, description);
        this.list.add(newTask);
        newTask.num = this.idCounter;
        this.idCounter++;
    }


    // печатает информацию о всех заданиях
    public void printAllTasks() {
        for (Process task : this.list) {
            System.out.println("ID " + task.num + ": " + task.name + "; выполнение: "+ task.Sost +"; описание: "+ task.Opis);
        }
    }

    // печатает информацию о всех выполненных заданиях
    public void printDoneTasks() {
        for (Process task : this.list) {
            if (task.Sost) {
                System.out.println("ID " + task.num + ": " + task.name + "; выполнение: "+ task.Sost +"; описание: "+ task.Opis);
            }
        }
    }

    // печатает информацию о всех невыполненных заданиях
    public void printUndoneTasks(){
        for (Process task:this.list) {
            if (!task.Sost){
                System.out.println("ID " + task.num + ": " + task.name + "; выполнение: "+ task.Sost +"; описание: "+ task.Opis);
            }
        }
    }

    // печатает информацию о всех заданиях по дате выполнения
    public void printAllTasksByDueDate(Calendar dueDate) {
        for (Process task : this.list) {
            if(equalDates(task.dueDate, dueDate)){
                System.out.println("ID " + task.num + ": " + task.name + "; выполнение: "+ task.Sost +"; описание: "+ task.Opis);
            }
        }
    }

    // печатает информацию о всех выполненных заданиях по дате выполнения
    public void printDoneTasksByDueDate(Calendar dueDate) {
        for (Process task : this.list) {
            if (task.Sost & equalDates(task.dueDate, dueDate)) {
                System.out.println("ID " + task.num + ": " + task.name + "; выполнение: "+ task.Sost +"; описание: "+ task.Opis);
            }
        }
    }

    // печатает информацию о всех невыполненных заданиях по дате выполнения
    public void printUndoneTasksByDueDate(Calendar dueDate){
        for (Process task:this.list) {
            if (!task.Sost & equalDates(task.dueDate, dueDate)){
                System.out.println("ID " + task.num + ": " + task.name + "; выполнение: "+ task.Sost +"; описание: "+ task.Opis);
            }
        }
    }

    // печатает информацию о всех заданиях по дате создания
    public void printAllTasksByCreationDate(Calendar creationDate) {
        for (Process task : this.list) {
            if(equalDates(task.creationDate, creationDate)){
                System.out.println("ID " + task.num + ": " + task.name + "; выполнение: "+ task.Sost +"; описание: "+ task.Opis);
            }
        }
    }

    // печатает информацию о всех выполненных заданиях по дате создания
    public void printDoneTasksByCreationDate(Calendar creationDate) {
        for (Process task : this.list) {
            if (task.Sost & equalDates(task.creationDate, creationDate)) {
                System.out.println("ID " + task.num + ": " + task.name + "; выполнение: "+ task.Sost +"; описание: "+ task.Opis);
            }
        }
    }

    // печатает информацию о всех невыполненных заданиях по дате создания
    public void printUndoneTasksByCreationDate(Calendar creationDate){
        for (Process task:this.list) {
            if (!task.Sost & equalDates(task.creationDate, creationDate)){
                System.out.println("ID " + task.num + ": " + task.name + "; выполнение: "+ task.Sost +"; описание: "+ task.Opis);
            }
        }
    }


    // Проверяет одинаковы ли даты
    public boolean equalDates(Calendar date1, Calendar date2){
        return date1.get(Calendar.YEAR) == date2.get(Calendar.YEAR) &
                date1.get(Calendar.MONTH) == date2.get(Calendar.MONTH) &
                date1.get(Calendar.DATE) == date2.get(Calendar.DATE);
    }
}

