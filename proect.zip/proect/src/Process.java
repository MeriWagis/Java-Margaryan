import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

class Process {
    int num; // Номер - должен генерироваться автоматически
    Calendar creationDate; // Дата создания
    Calendar dueDate; // Дата выполнения
    String name; // Наименование
    String Opis; // Детальное описание
    boolean Sost; // Выполнено ли

    Process(String name, Calendar dueDate){
        this.name = name;
        this.dueDate = dueDate;
        this.Opis = "";
        this.Sost = false;
        this.num = 0;
        this.creationDate = Calendar.getInstance();
    }
    Process(String name, Calendar dueDate, String Opis){
        this.name = name;
        this.dueDate = dueDate;
        this.Opis = Opis;
        this.Sost = false;
        this.num = 0;
        this.creationDate = Calendar.getInstance();
    }
    // Печать любой даты в формате dd.mm.yyyy
    public void printDate(Calendar cal){
        Date date = cal.getTime();
        SimpleDateFormat dt1 = new SimpleDateFormat("dd.MM.yyyy");
        System.out.println(dt1.format(date));
    }

    // Описание задания
    public void describeTask() {
        System.out.print("Task #" + this.num + ": *" + this.name + "* was created on ");
        printDate(this.creationDate);
        System.out.print("The due date is ");
        printDate(this.dueDate);
        System.out.println("Description: " + this.Opis);
        if (this.Sost){
            System.out.println("This task is DONE");
        }else {
            System.out.println("This task is NOT DONE");
        }
    }
}
