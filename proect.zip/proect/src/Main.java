
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
//        System.out.println("Hello world!");
//        Scanner in = new Scanner(System.in);
//        System.out.println("Введите  целочисленное число: ");
//        int num = in.nextInt();
//        System.out.println(num);
//        System.out.println("Введите  введите двойное число: ");
//        double num2 = in.nextDouble();
//        System.out.println("double: " + num2);
//        System.out.println("Введите  булево значение: ");
//        boolean boolValue = in.nextBoolean();
//        System.out.println("boolean: " + boolValue);
//        System.out.println("Введите  текст: ");
//        String name = in.next();
//        System.out.print("Input age: "+name);

        Baza list = new Baza();
        System.out.println("Программа запущена");
        help();
        Scanner scanner = new Scanner(System.in);
        {
            while (true) {
                System.out.println("Введите команду: ");
                String command = scanner.nextLine();
                if (command.equalsIgnoreCase("1")) {
                    create(scanner, list);
                    System.out.println("Создан!");
                    // 1 Создать
                } else if (command.equalsIgnoreCase("2")) {
                    delete(scanner, list);
                    System.out.println("Удален");
                    // 2 Удалить
                } else if (command.equalsIgnoreCase("3")) {
                    edit(scanner, list);
                    System.out.println("Отредактировано");
                    // 3 Отредактировать
                } else if (command.equalsIgnoreCase("4")) {
                    complete(scanner, list);
                    System.out.println("Изменен статус");
                    // 4 Отметить как выполненное
                } else if (command.equalsIgnoreCase("5")) {
                    info(scanner, list);
                    // 5 Получить детальную информацию
                } else if (command.equalsIgnoreCase("6.1")) {
                    System.out.println("База заданий");
                    list.printAllTasks();
                    // 6.1 Все
                } else if (command.equalsIgnoreCase("6.2")) {
                    System.out.println("Выполненные");
                    list.printDoneTasks();
                    // 6.2 Выполненные
                } else if (command.equalsIgnoreCase("6.3")) {
                    System.out.println("Невыполненные");
                    list.printUndoneTasks();
                    // 6.3 Невыполненные
                } else if (command.equalsIgnoreCase("7.1")) {
                    System.out.println("Все на дату");
                    seeAllByDueDate(scanner, list);
                    // 7.1 На дату все
                } else if (command.equalsIgnoreCase("7.2")) {
                    System.out.println("Выполненные на дату");
                    seeDoneByDueDate(scanner, list);
                    // 7.2 Выполненные на дату
                } else if (command.equalsIgnoreCase("7.3")) {
                    System.out.println("Невыполненные на дату");
                    seeUndoneByDueDate(scanner, list);
                    // 7.3 Невыполненные на дату
                } else if (command.equalsIgnoreCase("8.1")) {
                    System.out.println("Все на дату создания");
                    seeAllByCreationDate(scanner, list);
                    // 8.1 на дату создания
                } else if (command.equalsIgnoreCase("8.2")) {
                    System.out.println("Выполненные на дату создания");
                    seeDoneByCreationDate(scanner, list);
                    // 8.2 Выполненные на дату создания

                } else if (command.equalsIgnoreCase("8.3")) {
                    System.out.println("Невыполненные на дату создания");
                    seeUndoneByCreationDate(scanner, list);
                    // 8.3 Невыполненные на дату создания

                } else if (command.equalsIgnoreCase("0")) {
                    System.out.println("Программа завершена");
                    break;
                } else {
                    System.out.println("Ошибка! Попробуй снова");
                    help();
                }
            }
        }
    }

    public static boolean checkDate(String str) {
        if (!str.contains(".")) {
            return false;
        }
        String[] dateList = str.split("\\.");
        if (dateList.length != 3) {
            return false;
        }
        try {
            int day = Integer.parseInt(dateList[0]);
            int month = Integer.parseInt(dateList[1]);
            int year = Integer.parseInt(dateList[2]);
            Calendar newcal = new GregorianCalendar();
            newcal.setLenient(false);
            try {
                newcal.set(year, month - 1, day);
                newcal.getTime();
            } catch (Exception e) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

    // Устанавливает дату, используется только если дата уже проверена
    public static Calendar setDate(String str) {
        // Делит строку на части и присваивает значения календарю
        String[] dateList = str.split("\\.");
        int day = Integer.parseInt(dateList[0]);
        int month = Integer.parseInt(dateList[1]);
        int year = Integer.parseInt(dateList[2]);
        Calendar newcal = new GregorianCalendar();
        newcal.setLenient(false); // не дает выходить за пределы нормальных дат
        newcal.set(year, month - 1, day);
        return newcal;
    }

    // проверяет что имя не начинается с цифры
    public static boolean checkName(String name) {
        if (!name.equals("")) {
            return !Character.isDigit(name.charAt(0));
        }
        return true;
    }

    // Возвращает какая дата позже - первая или вторая (или 0, если равны)
    public static int laterDate(Calendar date1, Calendar date2) {
        if (date1.get(Calendar.YEAR) > date2.get(Calendar.YEAR)) {
            return 1;
        } else if (date1.get(Calendar.YEAR) == date2.get(Calendar.YEAR)) {
            if (date1.get(Calendar.MONTH) > date2.get(Calendar.MONTH)) {
                return 1;
            } else if (date1.get(Calendar.MONTH) == date2.get(Calendar.MONTH)) {
                if (date1.get(Calendar.DATE) > date2.get(Calendar.DATE)) {
                    return 1;
                } else if (date1.get(Calendar.DATE) > date2.get(Calendar.DATE)) {
                    return 0;
                }
            }
        }
        return 2;
    }

    // Ищет задание в планировщике по id
    public static Process findTask(String name, Baza list, Scanner scanner) {
        int taskID;
        System.out.println("База заданий");
        list.printAllTasks();
        try {
            taskID = Integer.parseInt(name);
        } catch (NumberFormatException e) {
            System.out.println("Введен неверный ID");
            return null;
        }
        for (Process task : list.list) {
            if (task.num - taskID == 0) {
                return task;
            }
        }
        return null;
    }
///////////////////////////////////////////////////////////////////////
    // МЕТОДЫ
    public static void create(Scanner scanner, Baza list) {
        String name;
        while (true) {
            System.out.println("Введите имя задания (не начинается с цифры))");
            name = scanner.nextLine().trim();
            if (name.equalsIgnoreCase("0")) {
                return;
            } else if (!checkName(name)) {
                System.out.println("Некорректное имя, попробуйте снова");
                System.out.println("Для отмены введите 0");
            } else { // имя подходит
                break;
            }
        }
        System.out.println("Описание задания:");
        String description = scanner.nextLine().trim();
        String date;
        while (true) { // проверяет дату
            System.out.println("Дедлайн, пример 24.05.2027. Важно! Дата создания < Дедлайна");
            date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("0")) {
                return;
            } else if (!checkDate(date)) {
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите 0");
            } else {
                if (laterDate(setDate(date), Calendar.getInstance()) == 2) {
                    System.out.println("Этот дедлайн раньше даты создания задания. Попробуйте снова или введите 0");
                } else {
                    break; // дата подходит
                }
            }
        }
        list.addTask(name, setDate(date), description);

    }

    public static void delete(Scanner scanner, Baza list) {
        while (true) {
            System.out.println("Введите ID задачи для УДАЛЕНИЯ");
            String name = scanner.nextLine().trim();
            if (name.equalsIgnoreCase("0")) {
                return;
            }
            Process task = findTask(name, list, scanner); // поиск задания по id
            if (task != null) {
                list.list.remove(task);
                System.out.println("Задача удалена");
                return;
            } else {
                System.out.println("Ошибка!");
                System.out.println("Попробуйте снова или введите 0");
            }
        }
    }
    public static void help(){
        File file = new File("demo.txt");

        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            reader.lines().forEach(System.out::println);
        } catch (
                IOException e) {
            e.printStackTrace();
        }
    }

    public static void edit(Scanner scanner, Baza list) {
        while (true) {
            System.out.println("ID задачи для изменения");
            String name = scanner.nextLine().trim();
            if (name.equalsIgnoreCase("0")) {
                return;
            }
            Process task = findTask(name, list, scanner);
            // поиск по id
            if (task != null) {
                while (true) {
                    System.out.println("Что вы хотите изменить? Введите due date, name или description. Или цифры 1, 2 или 3 соотвественно");
                    String what = scanner.nextLine().trim();

                    //смена деделайна + проверка даты
                    if (what.equalsIgnoreCase("1")) {
                        System.out.print("Сейчас дедлайн задания: ");
                        task.printDate(task.dueDate);
                        System.out.println("На что его заменить? (для отмены введите 0). Формат dd.mm.yyyy, например 15.04.2020");
                        String change = scanner.nextLine().trim();
                        if (!change.equalsIgnoreCase("0")) {
                            if (checkDate(change)) {  //дата в правильном формате
                                Calendar date_change = setDate(change);
                                if (laterDate(date_change, task.creationDate) == 2) {
                                    System.out.println("Этот дедлайн раньше даты создания задания. Попробуйте снова");
                                } else {
                                    task.dueDate = date_change;
                                    System.out.println("Дедлайн изменен");
                                    return;
                                }
                            } else {
                                System.out.println("Неверное введена дата, попробуйте снова");
                            }
                        } else {
                            return;
                        }

                    } else if (what.equalsIgnoreCase("2")) {
                        System.out.print("Сейчас имя задания: ");
                        System.out.println(task.name);
                        System.out.println("На что его заменить? (для отмены введите 0). Имя не может начинаться с цифры, не может быть словом 0");
                        String change = scanner.nextLine().trim();
                        if (!change.equalsIgnoreCase("0")) {
                            if (checkName(change)) {
                                task.name = change;
                                System.out.println("Имя изменено");
                                return;
                            } else {
                                System.out.println("Такое имя не подходит, попробуйте снова");
                            }
                        } else {
                            return;
                        }

                        // изменение описания
                    } else if (what.equalsIgnoreCase("3")) {
                        System.out.println("Сейчас описание задания: ");
                        System.out.println(task.Opis);
                        System.out.println("На что его заменить? (для отмены введите 0)");
                        String change = scanner.nextLine().trim();
                        if (!change.equalsIgnoreCase("0")) {
                            task.Opis = change;
                            System.out.println("Описание изменено");
                        }
                        return;
                    } else if (what.equalsIgnoreCase("0")) {
                        return;
                    } else { // фильтр ошибок при вводе
                        System.out.println("У задания нет такого свойства и его нельзя изменить");
                        System.out.println("Попробуйте снова или введите 0");
                    }
                }
            } else {
                System.out.println("Такой задачи не существует");
                System.out.println("Попробуйте снова или введите 0");
            }
        }
    }

    public static void complete(Scanner scanner, Baza list) {
        while (true) {
            System.out.println(" ID задачи, которую вы ВЫПОЛНИЛИ");
            String name = scanner.nextLine().trim();
            if (name.equalsIgnoreCase("0")) {
                return;
            }
            Process task = findTask(name, list, scanner); // поиск задачи по имени или номеру
            if (task != null) {
                if (task.Sost) {
                    System.out.println("Задача уже выполнена");
                } else {
                    task.Sost = true;
                    //task.dueDate = Calendar.getInstance();
                    System.out.println("Задача выполнена!");
                }
                return;
            } else {
                System.out.println("Нет задачи");
                System.out.println("Попробуй снова или введите 0");
            }
        }
    }

    public static void info(Scanner scanner, Baza list) {
        while (true) {
            System.out.println("Введите ID задачи для вывода информации");
            String name = scanner.nextLine().trim();
            if (name.equalsIgnoreCase("0")) {
                return;
            }
                int taskID = 0;
                try {
                    taskID = Integer.parseInt(name);
                } catch (NumberFormatException e) {
                    System.out.println("Введен неверный ID");
                    System.out.println("Попробуйте снова или введите 0");
                }
                for (Process task : list.list) {
                    if (task.num - taskID == 0) {
                        task.describeTask(); // выводит описание если такое задание есть
                        return;
                    }
                }
                System.out.println("Введен неверный ID");
                System.out.println("Попробуйте снова или введите 0");
            }
        }
    public static void seeAllByDueDate(Scanner scanner, Baza list) {
        while (true) {
            System.out.println("Дедлайн, пример 24.05.2027. Важно! Дата создания < Дедлайна");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("0")) {
                return;
            }
            if (checkDate(date)) {
                list.printAllTasksByDueDate(setDate(date));
                return;
            } else {
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите 0");
            }
        }
    }

    public static void seeDoneByDueDate(Scanner scanner, Baza list) {
        while (true) {
            System.out.println("Дедлайн, пример 24.05.2027. Важно! Дата создания < Дедлайна");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("0")) {
                return;
            }
            if (checkDate(date)) {
                list.printDoneTasksByDueDate(setDate(date));
                return;
            } else {
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите 0");
            }
        }
    }

    public static void seeUndoneByDueDate(Scanner scanner, Baza list) {
        while (true) {
            System.out.println("Дедлайн, пример 24.05.2027. Важно! Дата создания < Дедлайна");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("0")) {
                return;
            }
            if (checkDate(date)) {
                list.printUndoneTasksByDueDate(setDate(date));
                return;
            } else {
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите 0");
            }
        }
    }

    public static void seeAllByCreationDate(Scanner scanner, Baza list) {
        while (true) {
            System.out.println("Дедлайн, пример 24.05.2027. Важно! Дата создания < Дедлайна");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("0")) {
                return;
            }
            if (checkDate(date)) {
                list.printAllTasksByCreationDate(setDate(date));
                return;
            } else {
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите 0");
            }
        }
    }

    public static void seeDoneByCreationDate(Scanner scanner, Baza list) {
        while (true) {
            System.out.println("ВДедлайн, пример 24.05.2027. Важно! Дата создания < Дедлайна");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("0")) {
                return;
            }
            if (checkDate(date)) {
                list.printDoneTasksByCreationDate(setDate(date));
                return;
            } else {
                System.out.println("Некорректная дата, попробуй снова");
                System.out.println("Для отмены введите 0");
            }
        }
    }

    public static void seeUndoneByCreationDate(Scanner scanner, Baza list) {
        while (true) {
            System.out.println("Дедлайн, пример 24.05.2027. Важно! Дата создания < Дедлайна");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("0")) {
                return;
            }
            if (checkDate(date)) {
                list.printUndoneTasksByCreationDate(setDate(date));
                return;
            } else {
                System.out.println("Некорректная дата, попробуй снова");
                System.out.println("Для отмены введите 0");
            }
        }
    }
}