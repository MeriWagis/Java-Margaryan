package com.example.trainrest.services;

import com.example.trainrest.models.Flight;
import com.example.trainrest.models.Train;
import com.example.trainrest.repositories.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
/**
 * Сервис для поездов
 */
@Service
public class TrainService {
    @Autowired
    TrainRepository trainRepository;
    /**
     * Добавление поезда в бд
     * @param t Train
     */
    public void addTrain(Train t){
        trainRepository.save(t);
    }
    /**
     * Формирует запрос на добавление поезда в бд и обрабатывает результат
     * @param name String
     * @return Train
     */
    public Train findByName(String name){
        return trainRepository.findByName(name);
    }
    /**
     * Получение всех поездов
     * @return List из поездов
     */
    public List<Train> findAllTrains(){
        return trainRepository.findAll();
    }

}
