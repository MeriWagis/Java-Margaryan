package com.example.trainrest.controllers;

import com.example.trainrest.models.Carriage;
import com.example.trainrest.models.Flight;
import com.example.trainrest.models.Train;
import com.example.trainrest.models.TrainType;
import com.example.trainrest.services.Carriage_Service;
import com.example.trainrest.services.Flight_Service;
import com.example.trainrest.services.Train_Service;
import com.example.trainrest.util.Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
/**
 * Контроллер для поездов и рейсов
 */
@RestController
public class Controller {
    @Autowired
    Train_Service trainService;
    @Autowired
    Flight_Service flightService;
    @Autowired
    Carriage_Service carriageService;
    /**
     * Создает Train с переданными параметрами и сохраняет объект в бд
     * @param name String
     * @param type TrainType
     * @param seats int
     * @param carriage int
     */
    @PostMapping("addTrain")
    public ResponseEntity<?> addTrain(@RequestParam (name="name") String name, @RequestParam (name="type") TrainType type,
    @RequestParam (name="seats") int seats,@RequestParam (name="carriage") int carriage){
        Train train = new Train();
        train.setName(name);
        train.setTrainType(type);
        //создаем вагоны и добавляем их в поезд. В каждом поезде по carriage вагонов
        List<Carriage> carriages = Util.addCarriages(train, carriage, seats);
        for (Carriage c : carriages) {
            carriageService.addCarr(c);// добавляем вагон в базу данных
        }
        train.setCarriages(carriages);
        trainService.addTrain(train);
        return new ResponseEntity<>("Train added", HttpStatus.OK);
    }

    /**
     * Создает Flight с переданными параметрами и сохраняет объект в бд
     * @param cityFrom String
     * @param cityWhere String
     * @param departureDate String
     * @param arrivalDate String
     * @param departureTime String
     * @param arrivalTime String
     * @param basePrice int
     * @param trainName String
     */
    @PostMapping("addFlight")
    public ResponseEntity<?> addFlight(@RequestParam (name="cityFrom") String cityFrom, @RequestParam (name="cityWhere") String cityWhere, @RequestParam (name="departureDate") String departureDate ,
                                       @RequestParam (name="arrivalDate") String  arrivalDate,@RequestParam (name="departureTime") String departureTime,
                                       @RequestParam (name="arrivalTime") String arrivalTime,
                                       @RequestParam (name="basePrice") int basePrice, @RequestParam (name="train") String trainName){
        Flight flight = new Flight();
        Train train = trainService.findByName(trainName);
        flight.setCityFrom(cityFrom);
        flight.setCityWhere(cityWhere);
        flight.setDepartureDate(departureDate);
        flight.setDepartureTime(departureTime);
        flight.setArrivalDate(arrivalDate);
        flight.setArrivalTime(arrivalTime);
        flight.setTrain(train);
        flight.setBasePrice(basePrice);
        flightService.addFlight(flight);
        return new ResponseEntity<>("Flight added", HttpStatus.OK);
    }
    /**
     * Возвращает все найденнные поезда в бд
     * @return trains
     */
    @GetMapping("allTrains")
    public ResponseEntity<?> allTrains(){
        List<Train> trains = trainService.findAllTrains();
       //  System.out.println(trains);
        return new ResponseEntity<>(trains, HttpStatus.OK);
    }

   /**
     * Находит поезд по переданному имени и находит незанятое место в вагонах поезда.
     * После чего помечает его занятым.
     * @param trainName String
     */
    @PostMapping("/buyTicket")
    public ResponseEntity<?> buyTicket(@RequestParam (name="train") String trainName){
        Train train = trainService.findByName(trainName);
        for (int i = 0; i < train.getCarriages().size(); i++) {
            for (int j = 0; j < train.getCarriages().get(i).getFreeSeats().size(); j++) {
                boolean f = train.getCarriages().get(i).getFreeSeats().get(j);
                if(f){
                    train.getCarriages().get(i).getFreeSeats().set(j, false);
                    Carriage carriage = train.getCarriages().get(i);
                    carriageService.addCarr(carriage);
                    return new ResponseEntity<>("You've bought ticket", HttpStatus.OK);
                }
            }
        }

        return new ResponseEntity<>("No tickets", HttpStatus.OK);
    }
    /**
     * Возвращает все найденнные рейсы в бд
     * @return  flights
     */
    @GetMapping("allFlights")
    public ResponseEntity<?> allFlights(){
        List<Flight> flights = flightService.findAllFlights();
        //  System.out.println(flights);
        return new ResponseEntity<>(flights, HttpStatus.OK);
    }
    /**
     * Возвращает все имена поездов в бд. Это нужно для отображения имен поездов в таблице для рейсов.
     * @return trainNames
     */
    @GetMapping("trainsName")
    public ResponseEntity<?> trainsName(){
        List<String> trainNames = trainService.findAllTrains().stream().map(Train::getName).toList();
        return new ResponseEntity<>(trainNames, HttpStatus.OK);
    }

 
}
