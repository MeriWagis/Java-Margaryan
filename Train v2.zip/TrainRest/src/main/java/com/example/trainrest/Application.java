package com.example.trainrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(TrainRestApplication.class, args);
    }

}
