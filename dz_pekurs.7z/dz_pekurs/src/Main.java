import java.util.Arrays;
import java.util.Date;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("Задание 1");
        u1.printIntegers(5, 1);
        System.out.println("Задание 2");
        var test = u2.generateArray(100000000);
        Arrays.sort(test);
        var simple_search = new Thread(() -> {
            long start = System.nanoTime();
            var result = u2.simpleSearch(98, test);
            long end = System.nanoTime();
            System.out.println(Thread.currentThread().getName()+ " - " +
                    (end - start) / 1000000. + " мс.");
        }, "перебор ");

        var binary_search = new Thread(() -> {
            long start = System.nanoTime();
            var result = u2.binarySearch(test, -123, 0, test.length-1);
            long end = System.nanoTime();
            System.out.println(Thread.currentThread().getName()+ " - " +
                    (end - start) / 1000000. + " мс.");
        }, "бинарный  ");

        simple_search.start();
        binary_search.start();
        simple_search.join();
        binary_search.join();
        System.out.println("Задание 3");
        System.out.println(u3.find(0, 10));
        System.out.println("Задание 4");
       u4 test_tree = new u4() {
           {
               insert(7);
             insert(12);
               insert(24);
              insert(49);
             insert(77);
        }
     };
       System.out.println(test_tree);
    System.out.println(test_tree.search(27));
    }

}