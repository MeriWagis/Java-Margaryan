public class u1 {
    static void printIntegers(int n, int i){
        System.out.println(i);
        if (i < n)
            printIntegers(n, i+1);
    };
}
