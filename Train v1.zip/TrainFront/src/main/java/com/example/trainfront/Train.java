package com.example.trainfront;

import java.util.List;

public class Train {
    private Long id;
    private String name;

    private TrainType trainType;
    private int seats;

    private List<Carriage> carriages;

    public Train(Long id, String name, TrainType trainType, int seats, List<Carriage> carriages) {
        this.id = id;
        this.name = name;
        this.trainType = trainType;
        this.seats = seats;
        this.carriages = carriages;
    }

    public Train(String name, TrainType trainType, int seats, List<Carriage> carriages) {
        this.name = name;
        this.trainType = trainType;
        this.seats = seats;
        this.carriages = carriages;
    }

    public Train() {
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public TrainType getTrainType() {
        return trainType;
    }

    public void setTrainType(TrainType trainType) {
        this.trainType = trainType;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public List<Carriage> getCarriages() {
        return carriages;
    }

    public void setCarriages(List<Carriage> carriages) {
        this.carriages = carriages;
    }
}
