package com.example.trainfront;

import java.util.Objects;

public class FlightDAO {
    private String cityFrom;
    private String cityWhere;
    private String  departureDate;
    private String departureTime;
    private String  arrivalDate;
    private String arrivalTime;
    private int basePrice;
    private int seats;
    private int availableSeats;
    private String trainName;


    public FlightDAO(String cityFrom, String cityWhere, String departureDate, String departureTime, String arrivalDate, String arrivalTime, int basePrice, int seats,int availableSeats, String trainName) {
        this.cityFrom = cityFrom;
        this.cityWhere = cityWhere;
        this.departureDate = departureDate;
        this.departureTime = departureTime;
        this.arrivalDate = arrivalDate;
        this.arrivalTime = arrivalTime;
        this.basePrice = basePrice;
        this.seats = seats;
        this.availableSeats = availableSeats;
        this.trainName = trainName;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    public String getCityFrom() {
        return cityFrom;
    }

    public void setCityFrom(String cityFrom) {
        this.cityFrom = cityFrom;
    }

    public String getCityWhere() {
        return cityWhere;
    }

    public void setCityWhere(String cityWhere) {
        this.cityWhere = cityWhere;
    }

    public String getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(String departureDate) {
        this.departureDate = departureDate;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getArrivalDate() {
        return arrivalDate;
    }

    public void setArrivalDate(String arrivalDate) {
        this.arrivalDate = arrivalDate;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public int getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(int basePrice) {
        this.basePrice = basePrice;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public String getTrainName() {
        return trainName;
    }

    public void setTrainName(String trainName) {
        this.trainName = trainName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FlightDAO flightDAO = (FlightDAO) o;
        return basePrice == flightDAO.basePrice && seats == flightDAO.seats && Objects.equals(cityFrom, flightDAO.cityFrom) && Objects.equals(cityWhere, flightDAO.cityWhere) && Objects.equals(departureDate, flightDAO.departureDate) && Objects.equals(departureTime, flightDAO.departureTime) && Objects.equals(arrivalDate, flightDAO.arrivalDate) && Objects.equals(arrivalTime, flightDAO.arrivalTime) && Objects.equals(trainName, flightDAO.trainName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cityFrom, cityWhere, departureDate, departureTime, arrivalDate, arrivalTime, basePrice, seats, trainName);
    }

    @Override
    public String toString() {
        return "FlightDAO{" +
                "cityFrom='" + cityFrom + '\'' +
                ", cityWhere='" + cityWhere + '\'' +
                ", departureDate='" + departureDate + '\'' +
                ", departureTime='" + departureTime + '\'' +
                ", arrivalDate='" + arrivalDate + '\'' +
                ", arrivalTime='" + arrivalTime + '\'' +
                ", basePrice=" + basePrice +
                ", seats=" + seats +
                ", trainName='" + trainName + '\'' +
                '}';
    }
}
