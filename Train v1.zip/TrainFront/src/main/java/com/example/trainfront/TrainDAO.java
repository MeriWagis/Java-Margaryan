package com.example.trainfront;

import java.util.List;

public class TrainDAO {
    private String name;
    private TrainType trainType;
    private int seats;
    private int carriages;

    public TrainDAO(String name, TrainType trainType, int seats, int carriages) {
        this.name = name;
        this.trainType = trainType;
        this.seats = seats;
        this.carriages = carriages;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TrainType getTrainType() {
        return trainType;
    }

    public void setTrainType(TrainType trainType) {
        this.trainType = trainType;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public int getCarriages() {
        return carriages;
    }

    public void setCarriages(int carriages) {
        this.carriages = carriages;
    }
}
