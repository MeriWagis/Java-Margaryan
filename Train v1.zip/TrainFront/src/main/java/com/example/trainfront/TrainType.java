package com.example.trainfront;

public enum TrainType {
    lastochka,sapsan,strizh,nevsky;
}
