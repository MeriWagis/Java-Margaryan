package com.example.trainrest.util;

import com.example.trainrest.models.Carriage;
import com.example.trainrest.models.Train;
import java.util.ArrayList;
import java.util.List;

public class Util {

    public static List<Carriage> addCarriages(Train train, int amountCarr, int seats) {
        //создаем вагоны и добавляем их в поезд. В каждом поезде по amountCarr вагонов
        List<Carriage> carriages = new ArrayList<>();
        for (int i = 0; i < amountCarr; i++) {
            List<Boolean> b = new ArrayList<>();
            for (int j = 0; j < seats; j++) {
                b.add(true);
            }
            Carriage carriage = new Carriage(b);
            carriages.add(carriage);
        }
        return carriages;


    }


}
