package com.example.trainrest.models;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Carriage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ElementCollection
    List<Boolean> freeSeats;
    public Carriage(Long id, List<Boolean> freeSeats) {
        this.id = id;
        this.freeSeats = freeSeats;
    }

    public Carriage() {}

    public Carriage(List<Boolean> freeSeats) {
        this.freeSeats = freeSeats;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public List<Boolean> getFreeSeats() {
        return freeSeats;
    }

    public void setFreeSeats(List<Boolean> freeSeats) {
        this.freeSeats = freeSeats;
    }
}
