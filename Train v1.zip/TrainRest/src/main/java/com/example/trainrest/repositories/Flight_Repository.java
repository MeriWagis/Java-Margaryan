package com.example.trainrest.repositories;

import com.example.trainrest.models.Flight;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Flight_Repository extends JpaRepository< Flight,Long> {

}
