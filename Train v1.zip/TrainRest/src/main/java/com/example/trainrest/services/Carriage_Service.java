package com.example.trainrest.services;

import com.example.trainrest.models.Carriage;
import com.example.trainrest.repositories.Carriage_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Carriage_Service {

    @Autowired
    Carriage_Repository carriageRepository;

    public void addCarr(Carriage carriage){
        carriageRepository.save(carriage);
    }
}
