class StepThread extends Thread {
    private Object lock;
    public StepThread(Object object) {
        this.lock = object;
    }
    @Override
    public void run() {
        while (true) {
            synchronized (lock) {
                try {
                    System.out.println(getName());
                    lock.notify();
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
public class Main {
    public static void main(String[] strings) {
        System.out.println("Задание 1. Потоки");
        Object lock = new Object();
        new StepThread(lock).start();
        new StepThread(lock).start();
    }
}