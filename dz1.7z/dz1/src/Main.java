public class Main

{
    public static void main(String[] args) {
        System.out.println("2 Задание ");

        Vector v1 = new Vector(2, -3, 5);
        Vector v2 = new Vector(-4, 5, 20);
        System.out.println("Длина:" + v1.length());
        System.out.println("Скалярное произведение:" + v1.scalarProduct(v2));
        System.out.println("Векторное произведение:" + v1.crossProduct(v2));
        System.out.println("Косинус между векторами:" + v1.cos(v2));
        System.out.println("Сумма:" + v1.add(v2));
        System.out.println("Разность:" + v1.subtract(v2));
        System.out.println("Не меняет базовый " + v1.toString());

        System.out.println("3 Задание ");
        Ball ball = new Ball(3);
        Cylinder cylyinder = new Cylinder(5, 8);
        Pyramid pyramid = new Pyramid(20, 32);
        Box box = new Box(23);
        System.out.println(box.add(ball)); // ok
        System.out.println(box.add(cylyinder)); // ok
        System.out.println(box.add(pyramid)); // failed


    }
}
