package com.example.theatre.controllers;

import com.example.theatre.models.Afisha;
import com.example.theatre.services.AfishaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.Principal;

@Controller
@RequiredArgsConstructor
public class AfishaController {
    private final AfishaService afishaService;

    @GetMapping("/")
    public String afishas(@RequestParam(name = "title", required = false) String title, Principal principal, Model model) {
        model.addAttribute("afishas", afishaService.listAfishas(title));
        model.addAttribute("user", afishaService.getUserByPrincipal(principal));
        return "afishas";
    }

    @GetMapping("/afisha/{id}")
    public String afishaInfo(@PathVariable Long id, Model model) {
        Afisha afisha = afishaService.getAfishaById(id);
        model.addAttribute("afisha", afisha);
        model.addAttribute("images", afisha.getImages());
        return "afisha-info";
    }

    @PostMapping("/afisha/create")
    public String createAfisha(@RequestParam("file1") MultipartFile file1, @RequestParam("file2") MultipartFile file2,
                                @RequestParam("file3") MultipartFile file3, Afisha afisha, Principal principal) throws IOException {
        afishaService.saveAfisha(principal, afisha, file1, file2, file3);
        return "redirect:/";
    }

    @PostMapping("/oafish/delete/{id}")
    public String deleteAfisha(@PathVariable Long id) {
        afishaService.deleteAfisha(id);
        return "redirect:/";
    }
    @PutMapping("/oafish/put/{id}")
    public String putAfisha(@PathVariable Long id) {
        afishaService.putAfisha(id);
        return "redirect:/";
    }
}
