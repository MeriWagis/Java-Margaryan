package com.example.theatre.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "afishas")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Afisha {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;
    @Column(name = "title")
    private String title;
    @Column(name = "description", columnDefinition = "text")
    private String description;
    @Column(name = "price")
    private String price;
    @Column(name = "rows_place")
    private String rows_place;
    @Column(name = "time")
    private String time;
    @Column(name = "actor")
    private String actor;
//    @Column(name = "row")
//    private String row;
//    @Column(name = "place")
//    private String place;
//    @Column(name = "email_client")
//    private String email_client;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY,
    mappedBy = "afisha")
    private List<Image> images = new ArrayList<>();
    private Long previewImageId;
    @ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
    @JoinColumn
    private User user;
    private LocalDateTime dateOfCreated;

    @PrePersist
    private void init() {
        dateOfCreated = LocalDateTime.now();
    }

    public void addImageToAfisha(Image image) {
        image.setAfisha(this);
        images.add(image);
    }
}
