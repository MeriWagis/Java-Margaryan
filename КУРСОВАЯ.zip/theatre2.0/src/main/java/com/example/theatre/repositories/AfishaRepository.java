package com.example.theatre.repositories;

import com.example.theatre.models.Afisha;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AfishaRepository extends JpaRepository<Afisha, Long> {
    List<Afisha> findByTitle(String title);
}
