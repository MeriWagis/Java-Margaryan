package com.example.theatre.services;

import com.example.theatre.models.Image;
import com.example.theatre.models.Afisha;
import com.example.theatre.models.User;
import com.example.theatre.repositories.AfishaRepository;
import com.example.theatre.repositories.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class AfishaService {
    private final AfishaRepository afishaRepository;
    private final UserRepository userRepository;

    public List<Afisha> listAfishas(String title) {
        if (title != null) return afishaRepository.findByTitle(title);
        return afishaRepository.findAll();
    }

    public void saveAfisha(Principal principal, Afisha afisha, MultipartFile file1, MultipartFile file2, MultipartFile file3) throws IOException {
        afisha.setUser(getUserByPrincipal(principal));
        Image image1;
        Image image2;
        Image image3;
        if (file1.getSize() != 0) {
            image1 = toImageEntity(file1);
            image1.setPreviewImage(true);
            afisha.addImageToAfisha(image1);
        }
        if (file2.getSize() != 0) {
            image2 = toImageEntity(file2);
            afisha.addImageToAfisha(image2);
        }
        if (file3.getSize() != 0) {
            image3 = toImageEntity(file3);
            afisha.addImageToAfisha(image3);
        }
        log.info("Saving new Afisha. Title: {}; Author email: {}", afisha.getTitle(), afisha.getUser().getEmail());
        Afisha afishaFromDb = afishaRepository.save(afisha);
        afishaFromDb.setPreviewImageId(afishaFromDb.getImages().get(0).getId());
        afishaRepository.save(afisha);
    }

    public User getUserByPrincipal(Principal principal) {
        if (principal == null) return new User();
        return userRepository.findByEmail(principal.getName());
    }

    private Image toImageEntity(MultipartFile file) throws IOException {
        Image image = new Image();
        image.setName(file.getName());
        image.setOriginalFileName(file.getOriginalFilename());
        image.setContentType(file.getContentType());
        image.setSize(file.getSize());
        image.setBytes(file.getBytes());
        return image;
    }

    public void deleteAfisha(Long id) {
        afishaRepository.deleteById(id);
    }

    public void putAfisha(Long id ){
      afishaRepository.findById(id);
    };

    public Afisha getAfishaById(Long id) {
        return afishaRepository.findById(id).orElse(null);
    }
}
