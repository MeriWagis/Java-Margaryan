package com.blog.blog.controllers;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.blog.blog.models.Post;
import com.blog.blog.models.User;
import com.blog.blog.services.Post_Service;
import com.blog.blog.services.User_Service;

@RestController
@RequestMapping("/users")
public class User_Control {
    @Autowired
    private User_Service userService;

    @Autowired 
    private Post_Service postService;

    //добавление поста от имени пользователя
    @PostMapping("/{id}/posts/")    
    public void addPost(@PathVariable Integer id, @RequestBody Post post){
        User user = userService.getUserById(id);
        post.setUser(user);
        postService.savePost(post);
    }
    // получить список всех пользователей
    @GetMapping("")  
    public List<User> getAllUsers(){
        return userService.getAllUsers();
    }
    //получить пользователя по id
    @GetMapping("/{id}")  
    public ResponseEntity<User> get(@PathVariable Integer id){
        try{
            User user = userService.getUserById(id);
            return new ResponseEntity<User>(user, HttpStatus.OK);
        }
        catch(NoSuchElementException e){
            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
        }
    }
    // список пользователей по поискупо имени
    @GetMapping("/name/{name}")  
    public List<User> getUserByName(@PathVariable String name){
            return userService.getUserByName(name);
    }

    @PostMapping("/")  
    public void addUser(@RequestBody User user){
        userService.saveUser(user);
    }
    //удалить пользователя
    @DeleteMapping("/{id}")  
    public void deleteUser(@PathVariable Integer id){
        userService.deleteUser(id);
    }
    //изменить данных
    @PutMapping("/{id}")  
    public ResponseEntity<?> updateUser(@RequestBody User user, @PathVariable Integer id){
        try{
            User oldUser = userService.getUserById(id);
            oldUser.updateUser(user);
            userService.saveUser(oldUser);
            return new ResponseEntity<>(HttpStatus.OK);

        }catch(NoSuchElementException e){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    } 

}