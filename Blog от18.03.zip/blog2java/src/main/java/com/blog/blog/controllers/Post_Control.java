package com.blog.blog.controllers;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.blog.blog.models.Post;
import com.blog.blog.services.Post_Service;

@RestController
@RequestMapping("/posts")
public class Post_Control {

    @Autowired 
    private Post_Service postService;


    @GetMapping("")   //получить список всех постов
    public List<Post> getAllPosts(){
        return postService.getAllPosts();
    }

    @DeleteMapping("/{id}")  //удалить пост по id
    public void deletePost(@PathVariable Integer id){
        postService.deletePost(id);
    }

    @GetMapping("/{id}")  //получить пост по id
    public ResponseEntity<Post> getPost(@PathVariable Integer id){
        try{
            Post post = postService.getPostById(id);
            return new ResponseEntity<Post>(post, HttpStatus.OK);
        }catch(NoSuchElementException e){
            return new ResponseEntity<Post>(HttpStatus.NOT_FOUND);
        }
    }


    //пост можно добавить через /users/{id}/posts/


    @PutMapping("/{postId}/categories/{catId}")   //добавить категорию поста
    public Post addPostCategory(@PathVariable Integer catId, @PathVariable Integer postId){
        return postService.addPostCategory(postId, catId);
    }
}
