package com.blog.blog.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.blog.models.User;
import com.blog.blog.repositories.User_Repositor;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class User_Service {
    @Autowired
    private User_Repositor userRepository;

    public List<User> getAllUsers(){
        return userRepository.findAll();
    }

    public List<User> getUserByName(String name){
        return userRepository.findByName(name);
    }

    public void saveUser(User user){
        userRepository.save(user);
    }


    public void deleteUser(Integer id){
        userRepository.deleteById(id);
    }

    public User getUserById(Integer id){
        return userRepository.findById(id).get();
    }
}
