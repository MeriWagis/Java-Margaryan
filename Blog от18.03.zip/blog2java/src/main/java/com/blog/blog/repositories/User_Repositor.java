package com.blog.blog.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.blog.blog.models.User;

public interface User_Repositor extends JpaRepository<User, Integer>  {
    List<User> findByName(String name);  //поиск по имени пользователя
}
