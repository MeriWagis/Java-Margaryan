package com.blog.blog.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.blog.blog.models.Post;

public interface Post_Repositor extends JpaRepository<Post, Integer>  {
    
}
