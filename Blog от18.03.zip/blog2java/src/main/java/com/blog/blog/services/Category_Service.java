package com.blog.blog.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.blog.models.Category;
import com.blog.blog.repositories.Category_Repositor;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class Category_Service {
    @Autowired
    private Category_Repositor categoryRepository;

    public List<Category> getAllCategories(){
        return categoryRepository.findAll();
    }

    public Category getCategoryById(Integer id){
        return categoryRepository.findById(id).get();
    }

    public void saveCategory(Category category){
        categoryRepository.save(category);
    }

    public void deleteCategory(Integer id){
        categoryRepository.deleteById(id);
    }

    public Category getCategoryByName(String categoryName){
        return categoryRepository.findByCategoryName(categoryName);
    }
}
