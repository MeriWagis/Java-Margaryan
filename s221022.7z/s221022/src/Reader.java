import java.util.Arrays;
public class Reader {
    private String name;
    private int ticket;
    private String faculty;
    private String nom;
    private String date_birth;
    public Reader(String name, String faculty, String nom, String date_birth){
        this.name = name;
        this.faculty = faculty;
        this.nom = nom;
        this.date_birth = date_birth;
        this.ticket = (int) (Math.random() * 10000);}
    public String takeBook(int amount){
        return String.format("%s взял книги в количестве: %s.", name, amount);}
    public String takeBook(String... book){
        return String.format("%s взял книги в количестве: %s. " +
                "Названия книг: %s.", name, book.length, Arrays.toString(book));}
    public String takeBook(Book... book){
        return String.format("%s взял книги в количестве %s. " +
                "Названия книг: %s. ", name, book.length, Arrays.toString(book));}
    public String returnBook(int amount){
        return String.format("%s вернул книги в количестве: %s.", name, amount);}
    public String returnBook(String... book){
        return String.format("%s вернул книги в количестве: %s. " +
                "Названия книг: %s.", name, book.length, Arrays.toString(book));}
    public String returnBook(Book... book){
        return String.format("%s вернул книги в количестве %s. " +
                "Названия книг: %s", name, book.length, Arrays.toString(book));}
    public String toString(){
        return String.format("Имя: %s, факультет: %s, номер бил: %s, телефон: %s, дата рождения: %s.", name, faculty, ticket, nom, date_birth);}
}
