public class Main {
    public static void main(String[] args) {
        var r= new Reader("Анна", "ИТиАБД", "89164753597", "12-08-2002");
        System.out.println(r);
        System.out.println(r.takeBook(4));
        System.out.println(r.takeBook("Конец и вновь начало", "Время жить и время умирать"));
        System.out.println(r.takeBook(new Book("Капитанская дочка", "А. С. Пушкин")));
        System.out.println(r.returnBook(new Book("Капитанская дочка", "А. С. Пушкин")));
    }
}