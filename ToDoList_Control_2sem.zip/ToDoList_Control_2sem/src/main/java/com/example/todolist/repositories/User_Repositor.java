package com.example.todolist.repositories;

import com.example.todolist.models.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface User_Repositor extends JpaRepository<User,Long> {
        public User findByLogin(String login);

        public boolean existsByLogin(String login);
        public void deleteByLogin(String login);
}
