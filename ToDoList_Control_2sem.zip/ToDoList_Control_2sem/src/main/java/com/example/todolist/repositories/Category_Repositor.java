package com.example.todolist.repositories;

import com.example.todolist.models.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Category_repositor extends JpaRepository<Category,Long> {

    public boolean existsByName(String name);
    public void deleteByName(String name);

}
