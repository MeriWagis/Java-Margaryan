package com.example.todolist.services;

import com.example.todolist.models.Category;
import com.example.todolist.repositories.Category_Repositor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class Category_Service {
    @Autowired
    CategoryRepository categoryRepository;
    public Category findCatById(Long id){
        // выдвет категорию по id
        return categoryRepository.findById(id).get();
    }
    public Long updateCategory(Category category){
        // обновление бд
        category.setUpdateTime(new Date());
        return categoryRepository.save(category).getId();
    }
    public Long addCategory(Category category){
        // добавляет в бд и выдает Id
        category.setCreateTime(new Date());
        return categoryRepository.save(category).getId();
    }
    public void delCategory(String name){
        // удаляет категорию по имени
        categoryRepository.deleteByName(name);
    }
    public List<Category> getCategories(){
        // все категории 
        return categoryRepository.findAll();
    }
    public boolean existsByName(String name){
        // проверяет категорию по имени
        return categoryRepository.existsByName(name);
    }

}
