package com.example.todolist.controllers;

import com.example.todolist.models.User;
import com.example.todolist.services.Task_Service;
import com.example.todolist.services.Use_Service;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
/*
{   "login":"4",
    "firstName": "test5",
    "lastName":"1",
    "middleName":"1",
    "birthday":"2023-09-03"
}
 */

@RestController
public class User_Control {
    @Autowired
    private Use_Service userService;
    @Autowired
    private Task_Service taskService;

    @PostMapping("/addUser")
    public ResponseEntity<?> addUser(@RequestBody User user){
        // получает юзера и добавляет его в БД, если таких юзеров еще нет
        if(userService.existsByLogin(user.getLogin())){
            return new ResponseEntity<>("User already exist", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        Long id = userService.addUser(user);
        // возвращаем id созданного юзера
        return new ResponseEntity<>("User created, id: "+ id,HttpStatus.OK);
    }
    @GetMapping("/getUsers")
    public ResponseEntity<?> getUsers(){
        // возвращает всех юзеров из БД
        List<User> users = userService.getUsers();
        if(users.isEmpty()){
            return new ResponseEntity<>("No users yet",HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(users,HttpStatus.OK);
    }

    @DeleteMapping("/delUser")
    @Transactional
    public ResponseEntity<?> delUser(@RequestParam (name="login") String login){
        // удаляет юзера по логину, если он существует
        if(userService.existsByLogin(login)){
            userService.delUser(login);
            return new ResponseEntity<>("User deleted",HttpStatus.OK);
        }
        return new ResponseEntity<>("No users yet",HttpStatus.NOT_FOUND);
    }

    @PutMapping ("/updateUser")
    public ResponseEntity<?> updateUser(@RequestBody User user){
        // обновляет информацию о юзере, если он существует
        if(userService.existsByLogin(user.getLogin())){
            Long id = userService.updateUser(user);
            return new ResponseEntity<>("User " + id + "updated",HttpStatus.OK);
        }
        return new ResponseEntity<>("No users",HttpStatus.NOT_FOUND);
    }


}
