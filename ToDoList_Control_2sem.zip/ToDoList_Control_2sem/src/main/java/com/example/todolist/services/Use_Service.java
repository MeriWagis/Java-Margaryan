package com.example.todolist.services;

import com.example.todolist.models.User;
import com.example.todolist.repositories.User_Repositor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class Use_Service {

    @Autowired
    private User_Repositor userRepository;
        //добавление пользователя
    public Long addUser(User user){
        user.setCreateTime(new Date());
        return userRepository.save(user).getId();
    }
    // спсиок пользователей
    public List<User> getUsers(){
        return userRepository.findAll();
    }
    //удаление пользователей
    public void delUser(String login){
        userRepository.deleteByLogin(login);
    }
    //выводит по имени
    public User getUser(String login){
        return userRepository.findByLogin(login);
    }
    //поиск по ид пользователя
    public User findByID(Long id){
        return userRepository.findById(id).get();
    }
    //обновление
    public Long updateUser(User user){
        user.setUpdateTime(new Date());
        return userRepository.save(user).getId();
    }
    //выход
    public boolean existsByLogin(String login){
        return userRepository.existsByLogin(login);
    }
}
