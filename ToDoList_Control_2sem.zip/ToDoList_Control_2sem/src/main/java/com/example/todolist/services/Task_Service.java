package com.example.todolist.services;

import com.example.todolist.models.Task;
import com.example.todolist.models.User;
import com.example.todolist.repositories.Task_Repositor;
import com.example.todolist.repositories.User_Repositor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.Date;
import java.util.List;

@Service
public class Task_Service {
    @Autowired
    private Task_Repositor taskRepository;
    public List<Task> getTasks(){
        //выводит все задания 
        return taskRepository.findAll();
    }
    public Task findTaskByID(Long id){
        // ид
        return taskRepository.findById(id).get();
    }
    
    public Long updateTask(Task task){
        // обновление ид
        task.setUpdateTime(new Date());
        return taskRepository.save(task).getId();
    }
    public  Task getTask(String name){
        // выводит по имени
        return taskRepository.findTaskByName(name);
    }
    public void makeTask(String name){
        // изменение статуса задания
        Task task = getTask(name);
        task.makeTask();
        task.setDoneDate(new Date());
        taskRepository.save(task);
    }
    public boolean existsByName(String name){
        // поиск по имени
        return taskRepository.existsByName(name);
    }
    public void delTask(String name){
        // удаление задания
        taskRepository.deleteByName(name);
    }
    public Long addTask(Task task){
        // добавляет в бд и выводит ид
        task.setCreateTime(new Date());
        return taskRepository.save(task).getId();
    }





}
