import java.util.Collection;
import java.util.HashSet;
//удаляющий
public class UDL {
    public static <C> Collection<C> deleteDuplicates(Collection<C> collection) {
        return new HashSet<>(collection);
    }
}