
//замена

public interface zam {
    void add(str obj);
    void remove(str obj);
}