public class vivod implements str {
    public void onChanged(Data_baza builder, String changeDescription) {
        System.out.println("Object " + builder.hashCode() + " was changed — " + changeDescription + "] \n" +
                builder.toString());
    }
}