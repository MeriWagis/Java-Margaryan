import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class Main {
    public static void main(String[] args) throws IOException {
        var test_UndoStringBuilder = new UndoStringBuilder("Не буди лихо,");
        test_UndoStringBuilder.append(" пока оно тихо.");
        System.out.println(test_UndoStringBuilder);
        test_UndoStringBuilder.undo();
        System.out.println(test_UndoStringBuilder);

        var test_Data_baza = new Data_baza("Глаза боятся, ");
        var test_Observer = new vivod();
        test_Data_baza.add(test_Observer);
        test_Data_baza.append("а руки делают.");

        // словарь
        var test_text = Files.readString(Path.of("src\\tt.txt"));
        var dict = Worlds.get(test_text);
        System.out.println(dict);
    }
}