import java.util.*;
public class Worlds {
    private static String[] toWords(String text){
        return text.toLowerCase().split("[—–,!?;:\\s().^0-9\\n\\r]");}
    public static Map<String, Integer> get(String text) {
        var array_text = toWords(text);
        var slova = new HashMap<String, Integer>();
        for (var word : array_text) {
            if (Objects.equals(word, ""))
                continue;
            if (slova.containsKey(word))
                slova.put(word, slova.get(word) + 1);
            else
                slova.put(word, 1);
        }
        return slova;
    }
}