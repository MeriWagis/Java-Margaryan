
public interface str {
    void onChanged(Data_baza builder, String changeDescription);
}